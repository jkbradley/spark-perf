from setuptools import setup, find_packages

print(find_packages())

setup(
        name = "HelloWorld",
        version = "0.1",
        packages = find_packages(),
        )
